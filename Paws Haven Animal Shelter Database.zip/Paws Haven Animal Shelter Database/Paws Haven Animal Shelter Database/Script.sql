
--Create the database
CREATE DATABASE PawsHaven
ON
(
	NAME = 'PawHavenData1',
	FILENAME = 'C:\SQLWork\Project\PawHavenData1.mdf',
	SIZE = 20MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 10%
)

LOG ON 
(
	NAME = 'PawHavenLog1',
	FILENAME = 'C:\SQLWork\Project\PawHavenLog1.ldf',
	SIZE = 20MB,
	MAXSIZE = UNLIMITED,
	FILEGROWTH = 10%
)


GO
-- Use the database
USE PawsHaven
GO

-- Create the Staff Table
CREATE TABLE Staff (
    StaffID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    JobTitle VARCHAR(50),
    HireDate DATE,
    PhoneNumber VARCHAR(15) UNIQUE,
    Email VARCHAR(100) UNIQUE,
    CONSTRAINT CK_StaffJobTitle CHECK (JobTitle IN ('Manager', 'Veterinarian', 'Kennel Staff')),
	CONSTRAINT CK_Staff_Email CHECK (Email LIKE '%_@__%.__%')
);


GO
--Create a backup table for Staff
CREATE TABLE BackupStaff (
    StaffID INT,
    FirstName VARCHAR(50),
    LastName VARCHAR(50),
    JobTitle VARCHAR(50),
    HireDate DATE,
    PhoneNumber VARCHAR(15),
    Email VARCHAR(100)
);


GO
-- Create the Salary Table
CREATE TABLE Salary (
    SalaryID INT IDENTITY(1,1) PRIMARY KEY,
    StaffID INT FOREIGN KEY REFERENCES Staff(StaffID),
    SalaryAmount MONEY,
    PayPeriod VARCHAR(20),
    Bonus MONEY,
    EmploymentStatus VARCHAR(20),
    OvertimeAmount MONEY,
    CONSTRAINT CK_EmploymentStatus CHECK (EmploymentStatus IN ('Full-time', 'Part-time'))
);


GO
-- Create the Kennel Table
CREATE TABLE Kennel (
    KennelID INT IDENTITY(1,1) PRIMARY KEY,
    KennelCapacity INT,
    KennelType VARCHAR(50),
    CONSTRAINT CK_KennelType CHECK (KennelType IN ('Dog Kennel', 'Cat Kennel'))
);


GO
-- Create the StaffKennel Table
CREATE TABLE StaffKennel (
    StaffID INT FOREIGN KEY REFERENCES Staff(StaffID),
    KennelID INT FOREIGN KEY REFERENCES Kennel(KennelID)
);


GO
-- Create the Animal Table
CREATE TABLE Animal (
    AnimalID INT IDENTITY(1,1) PRIMARY KEY,
    KennelID INT FOREIGN KEY REFERENCES Kennel(KennelID),
    AnimalName VARCHAR(100),
    Breed VARCHAR(50),
    Age INT,
    Species VARCHAR(50),
    AdoptionStatus VARCHAR(20),
    CONSTRAINT CK_AdoptionStatus CHECK (AdoptionStatus IN ('Available', 'Adopted', 'On Hold'))
);


GO
-- Create the Adopter Table
CREATE TABLE Adopter (
    AdopterID INT IDENTITY(1,1) PRIMARY KEY,
    FirstName VARCHAR(50),
    SecondName VARCHAR(50),
    Address VARCHAR(255),
    City VARCHAR(50),
    PostalCode VARCHAR(20),
    PhoneNumber VARCHAR(15) UNIQUE,
    Email VARCHAR(50) UNIQUE,
	CONSTRAINT CK_Adopter_Email CHECK (Email LIKE '%_@__%.__%')
);


GO
-- Create the MedicalRecord Table
CREATE TABLE MedicalRecord (
    MedicalRecordID INT IDENTITY(1,1) PRIMARY KEY,
	AnimalID INT FOREIGN KEY REFERENCES Animal(AnimalID),
    Date DATE,
	CONSTRAINT CK_Med_Date CHECK (Date <= GETDATE()),
    TreatmentType VARCHAR(50),
    Notes VARCHAR(MAX)
);


GO
-- Create the AdoptionRecord Table
CREATE TABLE AdoptionRecord (
    AdoptionRecordID INT IDENTITY(1,1) PRIMARY KEY,
    AnimalID INT UNIQUE FOREIGN KEY REFERENCES Animal(AnimalID),
    AdopterID INT FOREIGN KEY REFERENCES Adopter(AdopterID),
    StaffID INT FOREIGN KEY REFERENCES Staff(StaffID),
    AdoptionFee MONEY,
    AdoptionDate DATE,
	CONSTRAINT CK_Adopt_Date CHECK (AdoptionDate <= GETDATE()),
);


GO
-- Add indexes
CREATE INDEX IX_AdoptionRecord_AnimalID ON AdoptionRecord(AnimalID);
CREATE INDEX IX_AdoptionRecord_AdopterID ON AdoptionRecord(AdopterID);
CREATE INDEX IX_AdoptionRecord_StaffID ON AdoptionRecord(StaffID);
CREATE INDEX IX_Animal_KennelID ON Animal(KennelID);
CREATE INDEX IX_Animal_AdoptionStatus ON Animal(AdoptionStatus);


GO
-- Insert sample data
-- Sample data for the Staff table
INSERT INTO Staff (FirstName, LastName, JobTitle, HireDate, PhoneNumber, Email)
VALUES
    ('John', 'Doe', 'Manager', '2020-01-01', '123-456-7890', 'john.doe@gmail.com'),
    ('Jane', 'Smith', 'Veterinarian', '2021-03-15', '987-654-3210', 'jane.smith@gmail.com'),
	('Sarah', 'Brown', 'Kennel Staff', '2022-06-20', '555-123-4567', 'sarah.brown@gmail.com'),
    ('David', 'Wilson', 'Kennel Staff', '2023-01-10', '444-789-0123', 'david.wilson@gmail.com'),
	('Michaela', 'Jones', 'Kennel Staff', '2022-09-15', '333-456-7890', 'michaela.jones@gmail.com'),
    ('Robert', 'Davis', 'Kennel Staff', '2023-02-20', '222-987-6543', 'robert.davis@gmail.com'),
    ('Emily', 'Robinson', 'Manager', '2021-08-10', '111-222-3333', 'emily.robinson@gmail.com'),
    ('Christopher', 'Lee', 'Veterinarian', '2022-04-05', '444-555-6666', 'christopher.lee@gmail.com'),
    ('Jessica', 'Wang', 'Kennel Staff', '2023-03-20', '777-888-9999', 'jessica.wang@gmail.com'),
    ('Daniel', 'Chen', 'Kennel Staff', '2023-10-15', '999-888-7777', 'daniel.chen@gmail.com'),
    ('Sophie', 'Garcia', 'Manager', '2022-01-20', '333-444-5555', 'sophie.garcia@gmail.com');


GO
--Insert Staff data into backup table
INSERT INTO BackupStaff (StaffID, FirstName, LastName, JobTitle, HireDate, PhoneNumber, Email)
SELECT * FROM Staff


GO
-- Sample data for the Salary table
INSERT INTO Salary (StaffID, SalaryAmount, PayPeriod, Bonus, EmploymentStatus, OvertimeAmount)
VALUES
    (1, 54000, 'Monthly', 2000.00, 'Full-time', 500.00),
    (2, 62000, 'Monthly', 0, 'Full-time', 0),
	(3, 1000, 'Weekly', 0, 'Part-time', 300.00),
    (4, 40000, 'Monthly', 0, 'Full-time', 400.00),
	(5, 32000, 'Monthly', 1000.00, 'Full-time', 0),
    (6, 38000, 'Monthly', 0, 'Full-time', 350.00),
	(7, 1100, 'Weekly', 0, 'Part-time', 600.00),
    (8, 60000, 'Monthly', 0, 'Full-time', 700.00),
    (9, 1050, 'Weekly', 0, 'Part-time', 300.00),
    (10, 40000, 'Monthly', 2000.00, 'Full-time', 0),
    (11, 52000, 'Monthly', 2800.00, 'Full-time', 650.00);
   
   
GO
-- Sample data for the Kennel table
INSERT INTO Kennel (KennelCapacity, KennelType)
VALUES
    (10, 'Dog Kennel'),
    (9, 'Cat Kennel'),
	(8, 'Cat Kennel'),
    (4, 'Dog Kennel'),
    (5, 'Dog Kennel');
  

GO
-- Sample data for the Animal table
INSERT INTO Animal (KennelID, AnimalName, Breed, Age, Species, AdoptionStatus)
VALUES
    (1, 'Buddy', 'Golden Retriever', 3, 'Dog', 'Available'),
    (2, 'Whiskers', 'Siamese', 2, 'Cat', 'Available'),
	(4, 'Max', 'Labrador Retriever', 2, 'Dog', 'Available'),
    (3, 'Fluffy', 'Persian', 4, 'Cat', 'On Hold'),
	(3, 'Milo', 'Maine Coon', 3, 'Cat', 'Available'),
    (5, 'Rocky', 'Bulldog', 4, 'Dog', 'Available'),
	(4, 'Bella', 'Labrador Retriever', 2, 'Dog', 'Available'),
    (2, 'Luna', 'Persian', 3, 'Cat', 'Available'),
    (1, 'Max', 'German Shepherd', 4, 'Dog', 'Available'),
    (2, 'Milo', 'Siamese', 2, 'Cat', 'Available'),
    (4, 'Charlie', 'Golden Retriever', 3, 'Dog', 'Available'),
	(1, 'Rocky', 'Boxer', 4, 'Dog', 'Available'),
	(1, 'Charlie', 'Poodle', 6, 'Dog', 'Adopted');
   

GO
-- Sample data for the Adopter table
INSERT INTO Adopter (FirstName, SecondName, Address, City, PostalCode, PhoneNumber, Email)
VALUES
    ('Michael', 'Johnson', '123 Main St', 'Anytown', '12345', '098 675 6534', 'michael.johnson@gmail.com'),
    ('Emily', 'Williams', '456 Elm St', 'Sometown', '67890', '085 542 5573', 'emily.williams@gmail.com'),
	('Emma', 'Brown', '789 Oak St', 'Othertown', '45678', '074 234 6521', 'emma.brown@gmail.com'),
    ('Daniel', 'Miller', '321 Pine St', 'Smalltown', '90123', '054 342 5646', 'daniel.miller@gmail.com'),
    ('Sophia', 'Taylor', '456 Cedar St', 'Largetown', '34567', '092 567 8642', 'sophia.taylor@gmail.com'),
    ('Oliver', 'Anderson', '789 Maple St', 'Hometown', '89012', '098 656 4327', 'oliver.anderson@gmail.com'),
	('Emma', 'King', '123 Elm St', 'Anytown', '12345', '021 233 5424', 'emma.king@gmail.com'),
    ('Olivia', 'Lopez', '456 Oak St', 'Sometown', '67890', '058 643 2345', 'olivia.lopez@gmail.com'),
    ('Aiden', 'Gomez', '789 Pine St', 'Othertown', '45678', '085 234 6542', 'aiden.gomez@gmail.com'),
    ('Noah', 'Martinez', '321 Cedar St', 'Largetown', '34567', '084 234 6588', 'noah.martinez@gmail.com'),
    ('Isabella', 'Hernandez', '654 Maple St', 'Smalltown', '90123', '077 543 6424', 'isabella.hernandez@gmail.com');


GO
-- Sample data for the MedicalRecord table
INSERT INTO MedicalRecord (AnimalID, Date, TreatmentType, Notes)
VALUES
    (1, '2023-04-15', 'Vaccination', 'Routine vaccination'),
    (2, '2023-05-01', 'Checkup', 'General health checkup'),
	(3, '2023-07-10', 'Spaying', 'Surgical procedure'),
    (4, '2023-08-05', 'Dental cleaning', 'Routine dental cleaning'),
    (2, '2023-09-10', 'Neutering', 'Surgical procedure'),
    (2, '2023-10-05', 'Flea treatment', 'Routine flea treatment'),
	(6, '2023-11-10', 'Spaying', 'Surgical procedure'),
    (7, '2023-12-05', 'Dental cleaning', 'Routine dental cleaning'),
    (8, '2023-09-20', 'Vaccination', 'Routine vaccination'),
    (9, '2023-10-15', 'Checkup', 'General health checkup'),
    (5, '2023-08-20', 'Neutering', 'Surgical procedure');


GO
-- Sample data for the AdoptionRecord table
INSERT INTO AdoptionRecord (AnimalID, AdopterID, StaffID, AdoptionFee, AdoptionDate)
VALUES
    (1, 1, 1, 100.00, '2023-05-20'),
    (2, 2, 2, 75.00, '2023-06-10'),
	(3, 1, 2, 120.00, '2023-07-25'),
    (4, 4, 4, 90.00, '2023-08-15'),
	(5, 1, 2, 110.00, '2023-09-25'),
    (6, 6, 6, 130.00, '2023-10-15'),
	(7, 7, 7, 150.00, '2023-11-25'),
    (8, 1, 2, 100.00, '2023-12-15'),
    (9, 9, 9, 160.00, '2023-09-30'),
    (10, 1, 2, 110.00, '2023-10-20'),
    (11, 11, 11, 170.00, '2023-08-25');


GO	
--Create backup of database
BACKUP DATABASE PawsHaven TO DISK = 'C:\SQLWork\Project\PawsHaven.bak' WITH FORMAT;


										--VIEWS--


GO
--Create view that stores salary details of staff and salary after overtime and bonus is applied
CREATE VIEW vEmpSalary
AS

	SELECT ST.StaffID, ST.FirstName + ' ' + ST.LastName AS 'FullName', SA.PayPeriod, SA.SalaryAmount, SUM(SA.SalaryAmount + SA.Bonus + SA.OvertimeAmount) AS 'Salary After AddOns'
	FROM Staff ST
	INNER JOIN Salary SA
	ON ST.StaffID = SA.StaffID
	GROUP BY ST.StaffID,  ST.FirstName + ' ' + ST.LastName, SA.PayPeriod, SA.SalaryAmount

--SELECT * FROM vEmpSalary


GO
--Create view that stores the details of adopters along with their animals
CREATE VIEW vAdopterAnimals
AS
	
	SELECT AD.FirstName, AD.SecondName, AD.Address, AN.AnimalName, AN.Breed, AR.AdoptionFee, AR.AdoptionDate
	FROM Adopter AD 
	INNER JOIN AdoptionRecord AR
	ON AD.AdopterID = AR.AdopterID
	INNER JOIN Animal AN
	ON AN.AnimalID = AR.AnimalID

--SELECT * FROM vAdopterAnimals


GO
--Create view that stores the top 5 staff earners 
CREATE VIEW vTopFulltimeSalaries
AS

	SELECT TOP 5 S.StaffID, S.FirstName, S.LastName, S.JobTitle, SA.SalaryAmount, SA.EmploymentStatus, DATEDIFF(YEAR, S.HireDate, GETDATE()) AS 'Years Of Working'
	FROM Staff S
	INNER JOIN Salary SA
	ON S.StaffID = SA.StaffID
	WHERE SA.EmploymentStatus = 'Full-time'
	ORDER BY SA.SalaryAmount DESC

--SELECT * FROM vTopFulltimeSalaries


GO
--Create view that stores how many animals are kept in the kennels and how many spaces are left
CREATE VIEW vKennelAnimalCount
AS

	SELECT K.KennelID, K.KennelType, COUNT(A.AnimalID) AS 'Total Animals in kennel', (K.KennelCapacity - COUNT(A.AnimalID)) AS 'Space left'
	FROM Kennel K
	INNER JOIN Animal A
	ON K.KennelID = A.KennelID
	GROUP BY K.KennelID, K.KennelType, k.KennelCapacity

--SELECT * FROM vKennelAnimalCount


GO
--Create view that stores animal details along with their medical details
CREATE VIEW vAnimalMedRecord
AS

	SELECT A.AnimalID, A.AnimalName, A.Breed, A.Age, SUM(A.AGE - DATEDIFF(YEAR, MR.DATE, GETDATE())) AS 'Age when visited', MR.MedicalRecordID, MR.Date, MR.TreatmentType, MR.Notes
	FROM Animal A
	INNER JOIN MedicalRecord MR 
	ON MR.AnimalID = A.AnimalID
	GROUP BY  A.AnimalID, A.AnimalName, A.Breed, A.Age, MR.MedicalRecordID, MR.Date,  MR.TreatmentType, MR.Notes

--SELECT * FROM vAnimalMedRecord


									--TRIGGERS--


GO
--Create trigger that will stop an animal being added if the given kennel is full
CREATE TRIGGER tr_KennelMaxCap
ON Animal
AFTER INSERT
AS
BEGIN
    DECLARE @kennelID INT;

    --USE A CURSOR TO ITERATE OVER EACH INSERTED ROW--
    DECLARE cursor_Inserted CURSOR FOR
    SELECT KennelID
    FROM INSERTED;

    OPEN cursor_Inserted;
    FETCH NEXT FROM cursor_Inserted INTO @kennelID;

    WHILE @@FETCH_STATUS = 0
    BEGIN        
        --PRINT MESSAGE AND ROLLBACK TRANSACTION IF THE KENNEL HAS REACHED ITS CAPACITY--
        IF (SELECT COUNT(AnimalID) FROM Animal WHERE KennelID = @kennelID) > (SELECT KennelCapacity FROM Kennel WHERE KennelID = @kennelID)
        BEGIN
            PRINT 'Kennel ' + CAST(@kennelID AS NVARCHAR(10)) + ' has exceeded its capacity.';
			ROLLBACK
        END

        FETCH NEXT FROM cursor_Inserted INTO @kennelID;
    END

    CLOSE cursor_Inserted
    DEALLOCATE cursor_Inserted
END


GO
--Create a trigger that will insert new rows into the backup table for Staff
CREATE TRIGGER tr_Backup
ON Staff
FOR INSERT
AS
BEGIN
	INSERT INTO BackupStaff
	SELECT * FROM INSERTED
END

									--PROCEDURES--


GO
--Create a function that will check if a staff member qualifies for a raise depending on how many animals 
--they have helped adopt
CREATE PROCEDURE sp_StaffRaise
@staffID INT
AS

BEGIN
--Declare variables
	DECLARE @animalsAdopted INT,
			@fullName VARCHAR(50),
			@salary MONEY,
			@salaryAfter MONEY

--Assigns values to variables
	SET @animalsAdopted = (SELECT COUNT(StaffID) FROM AdoptionRecord WHERE StaffID = @staffID GROUP BY StaffID)
	SELECT @fullName = ST.FirstName + ' ' + ST.LastName, @salary = SA.SalaryAmount 
	FROM Staff ST
	INNER JOIN Salary SA
	ON ST.StaffID = SA.StaffID
	WHERE ST.StaffID = @staffID

--Check if the staff member qualifies for a raise and how much of a raise they qualify for
	IF @animalsAdopted < 5  
		BEGIN
			PRINT @fullName + ' with StaffID = ' + CAST(@staffID AS VARCHAR(10)) + ' managed ' + CAST(@animalsAdopted AS VARCHAR(10))
			+ ' adoptions and does not qualify for a raise'
		END
	ELSE IF @animalsAdopted BETWEEN 5 AND 15  
		BEGIN
			SET @salaryAfter = @salary*(1+(5.0/100))
			PRINT @fullName + ' with StaffID = ' + CAST(@staffID AS VARCHAR(10)) + 
			' managed ' + CAST(@animalsAdopted AS VARCHAR(10)) + ' adoptions and qualifies for a raise of 5%.'
			PRINT 'Current salary: ' + CAST(@salary AS VARCHAR(20))
			PRINT 'Salary after raise: ' + CAST(@salaryAfter AS VARCHAR(20))
		END
	ELSE
		BEGIN
			SET @salaryAfter = @salary*(1+(15.0/100))
			PRINT @fullName + ' with StaffID = ' + CAST(@staffID AS VARCHAR(10)) + 
			' managed ' + CAST(@animalsAdopted AS VARCHAR(10)) + ' adoptions and qualifies for a raise of 15%.'
			PRINT 'Current salary: ' + CAST(@salary AS VARCHAR(20))
			PRINT 'Salary after raise: ' + CAST(@salaryAfter AS VARCHAR(20))
		END
	
END

--EXECUTE sp_StaffRaise 2


GO
--Create procedure that will insert a new record into Animal
ALTER PROCEDURE sp_InsertAnimal
@KennelID INT,
@Name VARCHAR(100),
@Breed VARCHAR(50),
@Age INT,
@Species VARCHAR(50),
@AdoptionStatus VARCHAR(20)
AS

BEGIN
	BEGIN TRY
		BEGIN TRANSACTION

		--Check if the animal is inserted into the right kennel type
		IF @Species != (SELECT LEFT(KennelType, 3) FROM Kennel WHERE KennelID = @KennelID)
			BEGIN
				ROLLBACK;
				PRINT 'Kennel is not suited for animal'
				RETURN;
			END
		
		--Check if a valid breed and name value is given
		IF PATINDEX('%[0-9]%', @Breed) > 0 OR PATINDEX('%[0-9]%', @Name) > 0
		BEGIN
			ROLLBACK; 
			PRINT 'Breed or AnimalName cannot contain numeric characters';	
			RETURN;
		END

		--Insert new record into the table
		INSERT INTO Animal (KennelID, AnimalName, Breed, Age, Species, AdoptionStatus)
		VALUES (@KennelID, @Name, @Breed, @Age, @Species, @AdoptionStatus)
		
		SELECT * FROM Animal

		COMMIT
	END TRY

	--Print message if an error occured when try to add new record
	BEGIN CATCH
	ROLLBACK;
	PRINT 'Incorrect values added. Transaction failed'	
	END CATCH
END 

--EXECUTE sp_InsertAnimal 4, 'Roger', 'Rotwieler', 4, 'Dog', 'Available'

--SELECT * FROM vKennelAnimalCount


GO
-- Create procedure that shows all the adoptions made during a specified date range
CREATE PROCEDURE sp_AdoptionRange
@startDate DATE,
@endDate DATE
AS
BEGIN
--Checks if start date is valid by seeing if its bigger than the end date
	IF @startDate > @endDate
		BEGIN
			PRINT 'The end date cannot be older than the start date'
			RETURN
		END

	SELECT AD.FirstName, AD.SecondName, AN.AnimalName, AN.Species, AR.AdoptionDate
	FROM Adopter AD
	INNER JOIN AdoptionRecord AR
	ON AD.AdopterID = AR.AdopterID
	INNER JOIN Animal AN
	ON AN.AnimalID = AR.AnimalID
	WHERE AR.AdoptionDate BETWEEN @startDate AND @endDate
END

--EXECUTE sp_AdoptionRange '2023-01-01', '2023-06-30'


GO
--Create procedure that will update the capacity of a given kennel
CREATE PROCEDURE sp_UpdateKennelCap
@kennelID INT,
@amount INT
AS
BEGIN
--Declare variables
	DECLARE @newAmount INT,
			@oldAmount INT

	--Check if the given kennel ID exists in the table
	IF @kennelID IN (SELECT KennelID FROM Kennel)
		BEGIN
		--Assign values to variables
			SET @oldAmount = (Select KennelCapacity FROM Kennel WHERE KennelID = @kennelID)
			SET @newAmount = @oldAmount + @amount

			--Increases kennel capacity if given amount is positive
			IF @amount > 0 
				BEGIN				
					UPDATE Kennel
					SET KennelCapacity = @newAmount
					WHERE KennelID = @kennelID

					PRINT 'Kennel number: ' + CAST(@KennelID AS VARCHAR(2))
					PRINT 'Old capacity: ' + CAST(@oldAmount AS VARCHAR(2))
					PRINT 'New capacity: ' + CAST(@newAmount AS VARCHAR(2))
				END
			
			--Decreases kennel capacity if given amount is negative
			ELSE IF @amount < 0			
				BEGIN
				DECLARE @spaceLeft INT
				SET @spaceLeft = (SELECT [Space left] FROM vKennelAnimalCount WHERE KennelID = @kennelID)

				--Checks if the kennel is being decreased by more than there is space for
					IF (@spaceLeft + @amount) < 0
						BEGIN
							PRINT 'Kennel cannot be reduced by ' + CAST(@amount AS VARCHAR(2)) + ' spaces, since it is too full'
						END
					ELSE 
					--Decreases kennel capacity by given amount
						BEGIN
							UPDATE Kennel
							SET KennelCapacity = @newAmount
							WHERE KennelID = @kennelID

							PRINT 'Kennel number: ' + CAST(@KennelID AS VARCHAR(2))
							PRINT 'Old capacity: ' + CAST(@oldAmount AS VARCHAR(2))
							PRINT 'New capacity: ' + CAST(@newAmount AS VARCHAR(2))
						END
				END
			ELSE PRINT '0 is not an accepted value'
	
		END
		ELSE PRINT 'KennelID ' + CAST(@kennelID AS VARCHAR(2)) + 'does not exist'
END

--EXECUTE sp_UpdateKennelCap 1, 2


								--FUNCTIONS--
GO
--Create function that will return the average adoption fee of either dogs or cats
CREATE FUNCTION udf_AvgAdoptionFee
(@species VARCHAR(30))
RETURNS DECIMAL (10,2)
BEGIN

--Declare variable
	DECLARE @avg DECIMAL (10,2)

--Assign value to variable 
	SELECT @avg = AVG(AdoptionFee) 
	FROM AdoptionRecord AR INNER JOIN Animal A 
	ON A.AnimalID = AR.AnimalID
	WHERE A.Species = @species

--Return the variable
	RETURN @avg
END

--PRINT 'Average adoption fee for dogs is: ' + CAST(dbo.udf_AvgAdoptionFee('Cat') AS VARCHAR(20))


									--LOGINS--
GO
--Create master key
CREATE MASTER KEY
ENCRYPTION BY PASSWORD = 'MASTER'


GO
--Create certificate
CREATE CERTIFICATE Certificate1
WITH SUBJECT = 'Certificate for PawsHaven'


GO
--Creation Of Roles
CREATE ROLE AdminRole;
CREATE ROLE UserRole;


--Creating usser loggins
Logins:
-- Created login "Admin" with password
CREATE LOGIN Admin WITH PASSWORD = 'ADMIN';


GO
-- Created database user "Admin" assigned to the login "Admin"
CREATE USER Admin FOR LOGIN Admin;


GO
-- Granted all permissions to the user "Admin"
EXEC sp_addrolemember 'db_owner', 'Admin';


GO
-- Create logins for users
CREATE LOGIN Ben_Dover
WITH PASSWORD = 'Ben11'
CREATE LOGIN Reggie_Longton
WITH PASSWORD = 'Reggie22'


GO
-- Create users for logins
CREATE USER Ben_Dover FOR LOGIN Ben_Dover;
CREATE USER Reggie_Longton FOR LOGIN Reggie_Longton;


GO
-- Create roles for different access levels
CREATE ROLE BenAccess;
CREATE ROLE ReggieAccess;


GO
-- Grant access to specific tables
GRANT SELECT, UPDATE, INSERT ON Salary TO Ben_Dover;
GRANT SELECT, UPDATE, INSERT ON Staff TO Ben_Dover;
GRANT SELECT, UPDATE, INSERT ON Kennel TO Ben_Dover;
GRANT SELECT ON Animal TO Ben_Dover;
GRANT SELECT ON Adopter TO Ben_Dover;
GRANT SELECT ON AdoptionRecord TO Ben_Dover;
GRANT SELECT ON MedicalRecord TO Ben_Dover;


GO
-- Grant access to specific tables
GRANT SELECT ON Salary TO Reggie_Longton;
GRANT SELECT ON Staff TO Reggie_Longton;
GRANT SELECT ON Kennel TO Reggie_Longton;
GRANT SELECT, UPDATE, INSERT ON Animal TO Reggie_Longton;
GRANT SELECT, UPDATE, INSERT ON Adopter TO Reggie_Longton;
GRANT SELECT, UPDATE, INSERT ON AdoptionRecord TO Reggie_Longton;
GRANT SELECT, UPDATE, INSERT ON MedicalRecord TO Reggie_Longton;


GO
-- Assign roles
ALTER ROLE BenAccess ADD MEMBER Ben_Dover;
ALTER ROLE ReggieAccess ADD MEMBER Reggie_Longton;


